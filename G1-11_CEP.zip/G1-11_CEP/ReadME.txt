transactions.txt contains the transaction of the customer perform by the account in the following format:
{'first-name': 'abiya', 'last_name': 'sohail', 'account_type': 'checking', 'transaction': 'deposit', 'amount': 890, 'date_time': '2023-07-09 23:36:36'}
This file will keep record of all the transactions of the account in certain time spam

customer_details.txt updates and keeps the reord of the balance in the following format:
{'Name': 'esbah', 'password': 'cupcake', 'first_name': 'abiya', 'last_name': 'sohail', 'current_balances': 1500}
This file helps the user to login to his account by entering the password